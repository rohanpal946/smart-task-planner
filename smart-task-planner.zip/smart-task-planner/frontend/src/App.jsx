import React from 'react'
import { Routes, Route } from 'react-router-dom'
import Home from './pages/Home'
import GoalDetail from './pages/GoalDetail'

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Routes>
        <Route path="/" element={<Home />} />
        <Route path="/goal/:id" element={<GoalDetail />} />
      </Routes>
    </div>
  )
}

export default App