export const formatDuration = (hours) => {
  if (hours < 8) {
    return `${hours} hour${hours !== 1 ? 's' : ''}`
  } else if (hours < 40) {
    const days = Math.ceil(hours / 8)
    return `${days} day${days !== 1 ? 's' : ''}`
  } else {
    const weeks = Math.ceil(hours / 40)
    return `${weeks} week${weeks !== 1 ? 's' : ''}`
  }
}

export const calculateEndDate = (startDate, hours) => {
  const businessHoursPerDay = 8
  const endDate = new Date(startDate)
  let remainingHours = hours
  
  while (remainingHours > 0) {
    endDate.setDate(endDate.getDate() + 1)
    // Skip weekends
    if (endDate.getDay() !== 0 && endDate.getDay() !== 6) {
      remainingHours -= businessHoursPerDay
    }
  }
  
  return endDate
}