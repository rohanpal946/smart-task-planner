import axios from 'axios'

const API_BASE = import.meta.env.VITE_API_BASE || 'http://localhost:8000'

const api = axios.create({
  baseURL: API_BASE,
  headers: {
    'Content-Type': 'application/json',
  },
})

export const generatePlan = async (planData) => {
  const response = await api.post('/plan', planData)
  return response.data
}

export const getGoal = async (goalId) => {
  const response = await api.get(`/goals/${goalId}`)
  return response.data
}

export const getGoals = async () => {
  const response = await api.get('/goals')
  return response.data
}

export const updateTaskStatus = async (taskId, status) => {
  const response = await api.put(`/tasks/${taskId}?status=${status}`)
  return response.data
}

export default api