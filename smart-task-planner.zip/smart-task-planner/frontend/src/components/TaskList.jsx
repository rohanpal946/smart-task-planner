import React from 'react'
import { Clock, AlertCircle, CheckCircle, PlayCircle } from 'lucide-react'

const TaskList = ({ tasks, onStatusChange }) => {
  const getStatusIcon = (status) => {
    switch (status) {
      case 'completed':
        return <CheckCircle className="h-5 w-5 text-green-500" />
      case 'in_progress':
        return <PlayCircle className="h-5 w-5 text-blue-500" />
      default:
        return <AlertCircle className="h-5 w-5 text-gray-400" />
    }
  }

  const getPriorityColor = (priority) => {
    switch (priority) {
      case 'high':
        return 'priority-high'
      case 'medium':
        return 'priority-medium'
      case 'low':
        return 'priority-low'
      default:
        return ''
    }
  }

  return (
    <div className="space-y-4">
      {tasks
        .sort((a, b) => a.order - b.order)
        .map((task, index) => (
          <div
            key={task.id}
            className={`task-card ${getPriorityColor(task.priority)}`}
          >
            <div className="flex items-start justify-between">
              <div className="flex-1">
                <div className="flex items-start space-x-3">
                  <div className="flex-shrink-0 w-8 h-8 bg-blue-100 rounded-full flex items-center justify-center mt-1">
                    <span className="text-sm font-medium text-blue-800">
                      {index + 1}
                    </span>
                  </div>
                  
                  <div className="flex-1">
                    <div className="flex items-center space-x-3 mb-2">
                      <h3 className="text-lg font-semibold text-gray-800">
                        {task.title}
                      </h3>
                      <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                        task.priority === 'high' 
                          ? 'bg-red-100 text-red-800'
                          : task.priority === 'medium'
                          ? 'bg-yellow-100 text-yellow-800'
                          : 'bg-green-100 text-green-800'
                      }`}>
                        {task.priority} priority
                      </span>
                    </div>
                    
                    {task.description && (
                      <p className="text-gray-600 mb-3">
                        {task.description}
                      </p>
                    )}
                    
                    <div className="flex flex-wrap gap-4 text-sm text-gray-500">
                      {task.estimated_duration_hours && (
                        <span className="flex items-center">
                          <Clock className="h-4 w-4 mr-1" />
                          {task.estimated_duration_hours} hours
                        </span>
                      )}
                      {task.dependencies && task.dependencies.length > 0 && (
                        <span className="flex items-center">
                          <AlertCircle className="h-4 w-4 mr-1" />
                          Depends on: {task.dependencies.join(', ')}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="flex items-center space-x-3 ml-4">
                {getStatusIcon(task.status)}
                <select
                  value={task.status}
                  onChange={(e) => onStatusChange(task.id, e.target.value)}
                  className="px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500 text-sm"
                >
                  <option value="pending">Pending</option>
                  <option value="in_progress">In Progress</option>
                  <option value="completed">Completed</option>
                </select>
              </div>
            </div>
          </div>
        ))}
    </div>
  )
}

export default TaskList