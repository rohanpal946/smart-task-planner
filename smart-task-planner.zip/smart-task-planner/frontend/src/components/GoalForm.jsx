import React, { useState } from 'react'
import { Sparkles } from 'lucide-react'

const GoalForm = ({ onSubmit, loading }) => {
  const [goal, setGoal] = useState('')
  const [timeframe, setTimeframe] = useState('')

  const handleSubmit = (e) => {
    e.preventDefault()
    onSubmit({ goal, timeframe })
  }

  return (
    <div className="bg-white rounded-xl shadow-lg p-6 mb-8">
      <div className="flex items-center mb-4">
        <Sparkles className="h-6 w-6 text-blue-600 mr-2" />
        <h2 className="text-2xl font-bold text-gray-800">Smart Task Planner</h2>
      </div>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            What goal would you like to achieve?
          </label>
          <textarea
            value={goal}
            onChange={(e) => setGoal(e.target.value)}
            placeholder="Example: Launch a mobile app in 3 weeks, Learn Spanish in 2 months, Plan a wedding in 6 months..."
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent transition-all"
            rows="3"
            required
          />
        </div>
        
        <div>
          <label className="block text-sm font-medium text-gray-700 mb-2">
            Desired Timeframe (optional)
          </label>
          <input
            type="text"
            value={timeframe}
            onChange={(e) => setTimeframe(e.target.value)}
            placeholder="Example: 2 weeks, 1 month, 90 days..."
            className="w-full px-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500 focus:border-transparent"
          />
        </div>
        
        <button
          type="submit"
          disabled={loading || !goal.trim()}
          className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-3 px-6 rounded-lg font-medium hover:from-blue-700 hover:to-purple-700 focus:outline-none focus:ring-2 focus:ring-blue-500 disabled:from-gray-400 disabled:to-gray-400 disabled:cursor-not-allowed transition-all flex items-center justify-center"
        >
          {loading ? (
            <>
              <div className="loading-spinner mr-2"></div>
              Generating Smart Plan...
            </>
          ) : (
            <>
              <Sparkles className="h-5 w-5 mr-2" />
              Generate AI-Powered Plan
            </>
          )}
        </button>
      </form>
    </div>
  )
}

export default GoalForm