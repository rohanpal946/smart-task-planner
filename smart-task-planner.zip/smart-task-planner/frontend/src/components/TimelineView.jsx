import React from 'react'
import { Calendar, Clock } from 'lucide-react'

const TimelineView = ({ tasks, summary }) => {
  const totalHours = tasks.reduce((sum, task) => sum + (task.estimated_duration_hours || 0), 0)
  const completedTasks = tasks.filter(task => task.status === 'completed').length
  const progress = tasks.length > 0 ? (completedTasks / tasks.length) * 100 : 0

  return (
    <div className="bg-white rounded-xl shadow-lg p-6 mb-6">
      <div className="flex items-center mb-4">
        <Calendar className="h-5 w-5 text-blue-600 mr-2" />
        <h3 className="text-lg font-semibold text-gray-800">Project Timeline</h3>
      </div>

      {summary && (
        <div className="bg-blue-50 border border-blue-200 rounded-lg p-4 mb-4">
          <p className="text-blue-800">{summary}</p>
        </div>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 mb-4">
        <div className="bg-gray-50 rounded-lg p-4 text-center">
          <div className="text-2xl font-bold text-gray-800">{tasks.length}</div>
          <div className="text-sm text-gray-600">Total Tasks</div>
        </div>
        <div className="bg-gray-50 rounded-lg p-4 text-center">
          <div className="text-2xl font-bold text-gray-800 flex items-center justify-center">
            <Clock className="h-5 w-5 mr-1" />
            {totalHours}
          </div>
          <div className="text-sm text-gray-600">Total Hours</div>
        </div>
        <div className="bg-gray-50 rounded-lg p-4 text-center">
          <div className="text-2xl font-bold text-gray-800">{completedTasks}</div>
          <div className="text-sm text-gray-600">Completed</div>
        </div>
      </div>

      {/* Progress Bar */}
      <div className="w-full bg-gray-200 rounded-full h-3">
        <div 
          className="bg-green-600 h-3 rounded-full transition-all duration-500"
          style={{ width: `${progress}%` }}
        ></div>
      </div>
      <div className="text-sm text-gray-600 mt-2 text-center">
        {Math.round(progress)}% Complete
      </div>
    </div>
  )
}

export default TimelineView