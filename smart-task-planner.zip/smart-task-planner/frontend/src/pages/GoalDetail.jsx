import React, { useState, useEffect } from 'react'
import { useParams, Link } from 'react-router-dom'
import { ArrowLeft } from 'lucide-react'
import TaskList from '../components/TaskList'
import TimelineView from '../components/TimelineView'
import { getGoal } from '../utils/api'

const GoalDetail = () => {
  const { id } = useParams()
  const [goal, setGoal] = useState(null)
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState('')

  useEffect(() => {
    const fetchGoal = async () => {
      try {
        const goalData = await getGoal(id)
        setGoal(goalData)
      } catch (err) {
        setError('Failed to load goal details')
      } finally {
        setLoading(false)
      }
    }

    fetchGoal()
  }, [id])

  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="loading-spinner"></div>
      </div>
    )
  }

  if (error || !goal) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <h2 className="text-xl font-semibold text-gray-800 mb-2">Goal not found</h2>
          <Link to="/" className="text-blue-600 hover:text-blue-800">
            Return to home
          </Link>
        </div>
      </div>
    )
  }

  return (
    <div className="min-h-screen bg-gray-50 py-8">
      <div className="max-w-4xl mx-auto px-4">
        <Link 
          to="/" 
          className="inline-flex items-center text-blue-600 hover:text-blue-800 mb-6"
        >
          <ArrowLeft className="h-4 w-4 mr-2" />
          Back to Home
        </Link>

        <div className="bg-white rounded-xl shadow-lg p-6 mb-6">
          <h1 className="text-3xl font-bold text-gray-800 mb-2">{goal.title}</h1>
          {goal.description && (
            <p className="text-gray-600 mb-4">{goal.description}</p>
          )}
          <div className="flex items-center text-sm text-gray-500">
            <span>Created: {new Date(goal.created_at).toLocaleDateString()}</span>
            {goal.timeframe && (
              <span className="ml-4">Timeframe: {goal.timeframe}</span>
            )}
          </div>
        </div>

        <TimelineView 
          tasks={goal.tasks} 
          summary={`Timeline for ${goal.title}`}
        />

        <div className="bg-white rounded-xl shadow-lg p-6">
          <h2 className="text-2xl font-bold text-gray-800 mb-6">Action Plan</h2>
          <TaskList tasks={goal.tasks} />
        </div>
      </div>
    </div>
  )
}

export default GoalDetail