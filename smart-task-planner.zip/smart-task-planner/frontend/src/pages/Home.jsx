import React, { useState } from 'react'
import { useNavigate } from 'react-router-dom'
import GoalForm from '../components/GoalForm'
import TaskList from '../components/TaskList'
import TimelineView from '../components/TimelineView'
import { generatePlan } from '../utils/api'

const Home = () => {
  const [plan, setPlan] = useState(null)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const navigate = useNavigate()

  const handleGeneratePlan = async (formData) => {
    setLoading(true)
    setError('')
    
    try {
      const result = await generatePlan(formData)
      setPlan(result)
      // Navigate to goal detail page
      navigate(`/goal/${result.goal_id}`)
    } catch (err) {
      setError(err.response?.data?.detail || 'Failed to generate plan. Please try again.')
    } finally {
      setLoading(false)
    }
  }

  const handleStatusChange = async (taskId, status) => {
    if (!plan) return
    
    try {
      // Update local state immediately for better UX
      setPlan(prev => ({
        ...prev,
        tasks: prev.tasks.map(task => 
          task.id === taskId ? { ...task, status } : task
        )
      }))
      
      // API call to update status
      await updateTaskStatus(taskId, status)
    } catch (err) {
      setError('Failed to update task status')
      // Revert on error
      setPlan(prev => ({
        ...prev,
        tasks: prev.tasks.map(task => 
          task.id === taskId ? { ...task, status: task.status } : task
        )
      }))
    }
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-purple-50 py-8">
      <div className="max-w-4xl mx-auto px-4">
        <GoalForm onSubmit={handleGeneratePlan} loading={loading} />
        
        {error && (
          <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded-lg mb-6">
            {error}
          </div>
        )}

        {plan && (
          <div className="space-y-6">
            <TimelineView 
              tasks={plan.tasks} 
              summary={plan.timeline_summary} 
            />
            
            <div className="bg-white rounded-xl shadow-lg p-6">
              <h2 className="text-2xl font-bold text-gray-800 mb-6">Your Action Plan</h2>
              <TaskList 
                tasks={plan.tasks} 
                onStatusChange={handleStatusChange}
              />
            </div>
          </div>
        )}
      </div>
    </div>
  )
}

export default Home