import os
import json
import logging
from typing import List, Dict, Any
from openai import OpenAI
from datetime import datetime, timedelta

logger = logging.getLogger(__name__)

class LLMService:
    def __init__(self):
        self.client = OpenAI(api_key=os.getenv("OPENAI_API_KEY"))
        
    def generate_task_plan(self, goal: str, timeframe: str = None) -> Dict[str, Any]:
        """Generate task breakdown using LLM reasoning"""
        
        prompt = self._build_prompt(goal, timeframe)
        
        try:
            response = self.client.chat.completions.create(
                model="gpt-4",
                messages=[
                    {
                        "role": "system",
                        "content": """You are an expert project planner. Break down goals into actionable tasks with:
                        - Logical dependencies
                        - Realistic time estimates
                        - Clear priorities
                        - Sequential ordering
                        
                        Return valid JSON with this structure:
                        {
                            "tasks": [
                                {
                                    "title": "Task name",
                                    "description": "Detailed description",
                                    "estimated_duration_hours": 8,
                                    "dependencies": ["task_id_or_description"],
                                    "priority": "high|medium|low",
                                    "order": 1
                                }
                            ],
                            "timeline_summary": "Overall timeline description"
                        }"""
                    },
                    {
                        "role": "user",
                        "content": prompt
                    }
                ],
                temperature=0.7,
                max_tokens=2000
            )
            
            content = response.choices[0].message.content
            return self._parse_response(content)
            
        except Exception as e:
            logger.error(f"LLM service error: {e}")
            return self._get_fallback_plan(goal, timeframe)
    
    def _build_prompt(self, goal: str, timeframe: str) -> str:
        base_prompt = f"Break down this goal into actionable tasks with suggested deadlines and dependencies: {goal}"
        
        if timeframe:
            base_prompt += f"\nTimeframe: {timeframe}"
            
        base_prompt += """
        Consider:
        - Task dependencies and prerequisites
        - Realistic time estimates in hours
        - Priority levels (high, medium, low)
        - Logical execution order
        - Potential bottlenecks
        
        Provide the response in the specified JSON format."""
        
        return base_prompt
    
    def _parse_response(self, content: str) -> Dict[str, Any]:
        """Parse LLM response and extract JSON"""
        try:
            # Extract JSON from response
            json_str = content.strip()
            if json_str.startswith("```json"):
                json_str = json_str[7:-3].strip()
            elif json_str.startswith("```"):
                json_str = json_str[3:-3].strip()
                
            return json.loads(json_str)
        except json.JSONDecodeError as e:
            logger.error(f"Failed to parse LLM response: {e}")
            return self._get_fallback_plan("fallback", "2 weeks")
    
    def _get_fallback_plan(self, goal: str, timeframe: str) -> Dict[str, Any]:
        """Provide fallback plan if LLM fails"""
        return {
            "tasks": [
                {
                    "title": "Define project scope and objectives",
                    "description": f"Clearly outline what needs to be achieved for: {goal}",
                    "estimated_duration_hours": 8,
                    "dependencies": [],
                    "priority": "high",
                    "order": 1
                },
                {
                    "title": "Create detailed project plan",
                    "description": "Break down into smaller actionable items with timelines",
                    "estimated_duration_hours": 16,
                    "dependencies": ["Define project scope and objectives"],
                    "priority": "high",
                    "order": 2
                }
            ],
            "timeline_summary": f"Basic plan for {goal}. Consider refining with more specific details."
        }