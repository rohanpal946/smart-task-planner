from fastapi import FastAPI, HTTPException, Depends
from fastapi.middleware.cors import CORSMiddleware
from sqlalchemy.orm import Session
from typing import List
import logging

from . import models, schemas
from .database import SessionLocal, engine, get_db
from .llm_service import LLMService

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

# Create database tables
models.Base.metadata.create_all(bind=engine)

app = FastAPI(title="Smart Task Planner API", version="1.0.0")

# CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:3000", "http://127.0.0.1:3000"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

llm_service = LLMService()

@app.post("/plan", response_model=schemas.PlanResponse)
async def create_plan(plan_request: schemas.PlanRequest, db: Session = Depends(get_db)):
    """Generate task plan for a goal"""
    try:
        # Generate plan using LLM
        llm_plan = llm_service.generate_task_plan(
            goal=plan_request.goal,
            timeframe=plan_request.timeframe
        )
        
        # Create goal in database
        db_goal = models.Goal(
            title=plan_request.goal,
            description=f"Plan for: {plan_request.goal}",
            timeframe=plan_request.timeframe
        )
        db.add(db_goal)
        db.flush()  # Get the goal ID without committing
        
        # Create tasks
        tasks = []
        for task_data in llm_plan["tasks"]:
            db_task = models.Task(
                goal_id=db_goal.id,
                title=task_data["title"],
                description=task_data.get("description", ""),
                estimated_duration_hours=task_data.get("estimated_duration_hours", 8),
                dependencies=str(task_data.get("dependencies", [])),
                priority=task_data.get("priority", "medium"),
                order=task_data.get("order", len(tasks) + 1)
            )
            db.add(db_task)
            tasks.append(db_task)
        
        db.commit()
        
        return schemas.PlanResponse(
            goal_id=db_goal.id,
            tasks=[schemas.Task.from_orm(task) for task in tasks],
            timeline_summary=llm_plan.get("timeline_summary", "")
        )
        
    except Exception as e:
        db.rollback()
        logger.error(f"Error creating plan: {e}")
        raise HTTPException(status_code=500, detail=str(e))

@app.get("/goals/{goal_id}", response_model=schemas.Goal)
async def get_goal(goal_id: str, db: Session = Depends(get_db)):
    """Get goal with all tasks"""
    goal = db.query(models.Goal).filter(models.Goal.id == goal_id).first()
    if not goal:
        raise HTTPException(status_code=404, detail="Goal not found")
    return goal

@app.get("/goals", response_model=List[schemas.Goal])
async def get_goals(skip: int = 0, limit: int = 100, db: Session = Depends(get_db)):
    """Get all goals"""
    goals = db.query(models.Goal).offset(skip).limit(limit).all()
    return goals

@app.put("/tasks/{task_id}")
async def update_task_status(
    task_id: str, 
    status: str, 
    db: Session = Depends(get_db)
):
    """Update task status"""
    task = db.query(models.Task).filter(models.Task.id == task_id).first()
    if not task:
        raise HTTPException(status_code=404, detail="Task not found")
    
    task.status = status
    db.commit()
    return {"message": "Task updated successfully"}

@app.get("/")
async def root():
    return {"message": "Smart Task Planner API"}

if __name__ == "__main__":
    import uvicorn
    uvicorn.run(app, host="0.0.0.0", port=8000)