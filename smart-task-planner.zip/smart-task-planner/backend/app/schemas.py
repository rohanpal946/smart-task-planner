from pydantic import BaseModel
from datetime import datetime
from typing import List, Optional

class TaskBase(BaseModel):
    title: str
    description: Optional[str] = None
    estimated_duration_hours: Optional[int] = None
    deadline: Optional[datetime] = None
    dependencies: Optional[str] = None
    priority: Optional[str] = None
    order: Optional[int] = None

class TaskCreate(TaskBase):
    pass

class Task(TaskBase):
    id: str
    goal_id: str
    status: str
    
    class Config:
        from_attributes = True

class GoalBase(BaseModel):
    title: str
    description: Optional[str] = None
    timeframe: Optional[str] = None

class GoalCreate(GoalBase):
    pass

class Goal(GoalBase):
    id: str
    created_at: datetime
    status: str
    tasks: List[Task] = []
    
    class Config:
        from_attributes = True

class PlanRequest(BaseModel):
    goal: str
    timeframe: Optional[str] = None

class PlanResponse(BaseModel):
    goal_id: str
    tasks: List[Task]
    timeline_summary: str